module.exports.run = async(client, message, args, guildConf) => {
	message.channel.send('<:windows_warn:759388355011018803> Ta komenda nie jest jeszcze gotowa...');
}

module.exports.config = {
	name: 'profile',
	permissionLevel: 1,
	aliases: [],
	filename: 'other/profile.js',
	disabled: false,
	description: {
		pl: "Wyświetla/ustawia Twój profil",
		en: "Shows/sets your profile"
	},
	ussuage: {
		pl: "{prefix}profile [użytkownik]\n{prefix}profile set",
		en: "{prefix}profile [user]\n{prefix}profile set"
	}
}