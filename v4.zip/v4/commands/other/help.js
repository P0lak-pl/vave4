module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('other/help', 'pl');

	if(!args.length) {
		const embed = lang.buildEmbed(message)[0];
	
		let commands = {
			beta: [],
			bot: [],
			dev: [],
			fun: [],
			levels: [],
			moderation: [],
			music: [],
			other: [],
			tools: []
		};

		client.commands.forEach(command => {
			let filename = command.config.filename.split('/');
			if(filename[0] == 'hidden') return;
			commands[filename[0]].push(filename[1].replace('.js', ''))
		});

		let output = {
			beta: '',
			bot: '', // Done
			dev: '', // Done
			fun: '', // Done
			levels: '',
			moderation: '', // Done
			music: '', // Done
			other: '', // Done
			tools: '' // Done
		};
		
		if(commands.moderation !== []) {
			commands.moderation.forEach(cmd => {
				output.moderation += `\`${cmd}\`, `
			});
		}
		if(commands.tools !== []) {
			commands.tools.forEach(cmd => {
				output.tools += `\`${cmd}\`, `
			});
		}
		if(commands.music !== []) {
			commands.music.forEach(cmd => {
				output.music += `\`${cmd}\`, `
			});
		}
		if(commands.fun !== []) {
			commands.fun.forEach(cmd => {
				output.fun += `\`${cmd}\`, `
			});
		}
		if(commands.other !== []) {
			commands.other.forEach(cmd => {
				output.other += `\`${cmd}\`, `
			});
		}
		if(commands.bot !== []) {
			commands.bot.forEach(cmd => {
				output.bot += `\`${cmd}\`, `
			});
		}
		if(commands.levels !== []) {
			commands.levels.forEach(cmd => {
				output.levels += `\`${cmd}\`, `
			});
		}
		if(commands.beta !== []) {
			commands.beta.forEach(cmd => {
				output.beta += `\`${cmd}\`, `
			});
		}
		if(commands.dev !== []) {
			commands.dev.forEach(cmd => {
				output.dev += `\`${cmd}\`, `
			});
		}

		if(output.beta == '') output.beta = '-';
		else output.beta = output.beta.slice(0, -2);
		if(output.bot == '') output.bot = '-';
		else output.bot = output.bot.slice(0, -2);
		if(output.dev == '') output.dev = '-';
		else output.dev = output.dev.slice(0, -2);
		if(output.fun == '') output.fun = '-';
		else output.fun = output.fun.slice(0, -2);
		if(output.levels == '') output.levels = '-';
		else output.levels = output.levels.slice(0, -2);
		if(output.moderation == '') output.moderation = '-';
		else output.moderation = output.moderation.slice(0, -2);
		if(output.music == '') output.music = '-';
		else output.music = output.music.slice(0, -2);
		if(output.other == '') output.other = '-';
		else output.other = output.other.slice(0, -2);
		if(output.tools == '') output.tools = '-';
		else output.tools = output.tools.slice(0, -2);

		//console.log(output);

		embed
			.addField(`<:icon_ban:745604320291979294> Moderacja (${commands.moderation.length})`, output.moderation)
			.addField(`<:icon_settings:745604319377621093> Narzędzia (${commands.tools.length})`, output.tools)
			.addField(`<:icon_headphones:745604319675547710> Muzyka (${commands.music.length})`, output.music)
			.addField(`<:icon_emoji:745611418400850023> Fun (${commands.fun.length})`, output.fun)
			.addField(`<:icon_bot:745604320103497789> Bot (${commands.bot.length})`, output.bot)
			.addField(`:medal: Poziomy (${commands.levels.length})`, output.levels)
			.addField(`<:badge_early_supporter:774005845893578802> Beta (${commands.beta.length})`, output.beta)
			.addField(`<:badge_dev:745604319566626826> Dev (${commands.dev.length})`, output.dev)
			.addField(`<:icon_presence:745604319654576158> Inne (${commands.other.length})`, output.other)
			.addField(`<:icon_join:745604319927336992> Własne komendy (-)`, 'Prace nad własnymi komendami ciągle trwają, nie są jeszcze gotowe...');
		
		message.channel.send(embed);
	} else {
		const command = client.commands.get(args[0]) || client.commands.find(x => x.aliases && x.aliases.includes(args[0]));

		if(!command) {
			message.channel.send(lang.buildEmbed(message, [{
				"from": "name",
				"to": args[0]
			}])[2]);
		} else {

			let permissions = `1. ${lang.permissionLevels('1')}`;
			let aliases = '';
			let category = lang.commandCategories(command.config.filename.split('/')[0]);

			if(command.config.permissionLevel == 2) permissions = `2. ${lang.permissionLevels('2')}`
			if(command.config.permissionLevel == 3) permissions = `3. ${lang.permissionLevels('3')}`
			if(command.config.permissionLevel == 4) permissions = `4. ${lang.permissionLevels('4')}`
			if(command.config.permissionLevel == 5) permissions = `5. ${lang.permissionLevels('5')}`

			if(command.config.aliases.length == 0) {
				aliases = '\`Brak\`';
			}  else {
				command.config.aliases.forEach(a => aliases += `\`${a}\`, `);
				aliases = aliases.slice(0, -2);
			}

			let name = command.config.name;
			let disabled = command.config.disabled;
			let cooldown = command.config.cooldown;
			let description = command.config.description;
			let ussuage = command.config.ussuage;

			if(cmd.config.hasOwnProperty('overrideDefauts')) {
				if(cmd.config.overrideDefauts.hasOwnProperty('name')) name = cmd.config.overrideDefauts.name;
				if(cmd.config.overrideDefauts.hasOwnProperty('aliases')) aliases = cmd.config.overrideDefauts.aliases;
				if(cmd.config.overrideDefauts.hasOwnProperty('permissions')) permissions = cmd.config.overrideDefauts.permissions;
				if(cmd.config.overrideDefauts.hasOwnProperty('disabled')) disabled = cmd.config.overrideDefauts.disabled;
				if(cmd.config.overrideDefauts.hasOwnProperty('cooldown')) cooldown = cmd.config.overrideDefauts.cooldown;
				if(cmd.config.overrideDefauts.hasOwnProperty('category')) category = cmd.config.overrideDefauts.category;
				if(cmd.config.overrideDefauts.hasOwnProperty('description')) description = cmd.config.overrideDefauts.description;
				if(cmd.config.overrideDefauts.hasOwnProperty('ussuage')) ussuage = cmd.config.overrideDefauts.ussuage;
			}

			const embed = lang.buildEmbed(message, [
				{
					"from": "commandName",
					"to": name
				},
				{
					"from": "aliasesCount",
					"to": aliases.length
				},
				{
					"from": "aliases",
					"to": aliases
				},
				{
					"from": "permissions",
					"to": permissions
				},
				{
					"from": "off",
					"to": disabled ? "Tak" : "Nie"
				},
				{
					"from": "cooldown",
					"to": cooldown
				},
				{
					"from": "category",
					"to": category
				},
				{
					"from": "description",
					"to": description['pl']
				},
				{
					"from": "ussuage",
					"to": ussuage['pl'].split('{prefix}').join(guildConf.prefix)
				}
			])[1];

			//console.log(embed);

			message.channel.send(embed);
		}
	}
}

module.exports.config = {
	name: 'help',
	permissionLevel: 1,
	aliases: ['h'],
	filename: 'other/help.js',
	disabled: false,
	args: 1,
	description: {
		pl: "Wyświetla informacje o komendach",
		en: "Displays information about commands"
	},
	ussuage: {
		pl: "{prefix}help [nazwa komendy]",
		en: "{prefix}help [command name]"
	}
}