module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('tools/serverinfo', 'pl');
	
	let g = message.guild;
	let bans = await g.fetchBans();

	message.channel.send(lang.buildEmbed(message, [
		{
			"from": "name",
			"to": g.name
		},
		{
			"from": "id",
			"to": g.id
		},
		{
			"from": "members:online",
			"to": g.members.cache.filter(x => x.presence.status == 'online').size
		},
		{
			"from": "members:idle",
			"to": g.members.cache.filter(x => x.presence.status == 'idle').size
		},
		{
			"from": "members:dnd",
			"to": g.members.cache.filter(x => x.presence.status == 'dnd').size
		},
		{
			"from": "members:offline",
			"to": g.members.cache.filter(x => x.presence.status == 'offline').size
		},
		{
			"from": "members:bots",
			"to": g.members.cache.filter(x => x.user.bot == true).size
		},
		{
			"from": "members:all",
			"to": g.members.cache.size
		},
		{
			"from": "channels:text",
			"to": g.channels.cache.filter(x => x.type == 'text').size
		},
		{
			"from": "channels:voice",
			"to": g.channels.cache.filter(x => x.type == 'voice').size
		},
		{
			"from": "owner",
			"to": g.owner.id
		},
		{
			"from": "roles",
			"to": g.roles.cache.size
		},
		{
			"from": "emojis",
			"to": g.emojis.cache.size
		},
		{
			"from": "bans",
			"to": bans.size
		},
		{
			"from": "boosts",
			"to": g.premiumSubscriptionCount
		}
	]))
}

module.exports.config = {
	name: 'serverinfo',
	permissionLevel: 1,
	aliases: ['si'],
	filename: 'tools/serverinfo.js',
	disabled: false,
	description: {
		pl: "Wyświetla informacje o serwerze",
		en: "Displays information about server"
	},
	ussuage: {
		pl: "{prefix}serverinfo",
		en: "{prefix}serverinfo"
	}
}