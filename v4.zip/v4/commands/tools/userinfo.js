const Discord = require('discord.js');
const moment = require('moment');
const fetch = require('node-fetch');
const db = require('quick.db');

module.exports.run = async(client, message, args, guildConf) => {
	let user// = message.author;
	if(client.functions.getUserFromMention(args[0], client) !== undefined) user = client.functions.getUserFromMention(args[0], client);
	else user = message.author;

	//console.log(user);

	if(!user) return message.channel.send(new client.LanguageHandler('_err_userNotFound', 'pl').buildEmbed(message));

	let status = '<:no:750005917562437723> \`Wystąpił błąd\`';

	if(user.presence.status == 'online') status = '<:status_online:745604320120012810> \`Online\`';
	if(user.presence.status == 'idle') status = '<:status_idle:745604319973474426> \`Zaraz wracam\`';
	if(user.presence.status == 'dnd') status = '<:status_dnd:745604320304824370> \`Nie przeszkadzać\`';
	if(user.presence.status == 'offline') status = '<:status_offline:745604320376127531> \`Offline\`';
	if(user.presence.status == 'streaming') status = '<:status_streaming:745604320715866222> \`Streamuje\`';

	let noteUrl = db.get(user.id + '_note') || '';
	let note = db.get(user.id + '_note') || 'Brak';

	const response = await fetch(`https://scriptchip.cf/v2/imageGeneration/discordUserProfile?status=${user.presence.status}&avatar=${user.displayAvatarURL(client.ImageURLOptions)}&username=${user.username}&discriminator=${user.discriminator}&note=${noteUrl}`, {
		method: 'get',
		headers: {'Authorization': 'ksc8FCqegfPaTBPTTKaq2GqfiKWrSZ9VKCKVVNSU'}
	});

	const arrayBuffer = await response.arrayBuffer();
	const buffer = Buffer.from(arrayBuffer);

	const attachment = new Discord.MessageAttachment(buffer, 'ui.png'); 

	const lang = new client.LanguageHandler('tools/userinfo', 'pl');
	
	if(message.guild.members.cache.get(user.id)) {

		let nick = 'Brak';

		if(message.guild.members.cache.get(user.id).nickname !== null) nick = message.guild.members.cache.get(user.id).nickname;

		message.channel.send(lang.buildEmbed(message, [
			{
				"from": "badges",
				"to": client.functions.badgesGenerator(user.id)
			},
			{
				"from": "status",
				"to": status
			},
			{
				"from": "dateCreation",
				"to": moment(user.createdAt).format("DD.MM.YYYY HH:mm:ss")
			},
			{
				"from": "dateJoin",
				"to": moment(message.guild.members.cache.get(user.id).joinedAt).format("DD.MM.YYYY HH:mm:ss")
			},
			{
				"from": "id",
				"to": user.id
			},
			{
				"from": "avatar",
				"to": user.displayAvatarURL(client.ImageURLOptions)
			},
			{
				"from": "nick",
				"to": "\`" + nick + "\`"
			},
			{
				"from": "description",
				"to": '\`' + note + '\`'
			}
		]).setTitle('Informacje o użytkowniku ' + user.tag).setThumbnail(user.displayAvatarURL(client.ImageURLOptions)).attachFiles(attachment).setImage('attachment://ui.png'));
	} else {
		message.channel.send(lang.buildEmbed(message, [
			{
				"from": "badges",
				"to": client.functions.badgesGenerator(user.id)
			},
			{
				"from": "status",
				"to": status
			},
			{
				"from": "dateCreation",
				"to": moment(user.createdAt).format("DD.MM.YYYY HH:mm:ss")
			},
			{
				"from": "dateJoin",
				"to": "\`*Not on guild*\`"
			},
			{
				"from": "id",
				"to": user.id
			},
			{
				"from": "avatar",
				"to": user.displayAvatarURL(client.ImageURLOptions)
			},
			{
				"from": "nick",
				"to": "\`*Not on guild*\`"
			},
			{
				"from": "description",
				"to": note
			}
		]).setTitle('Informacje o użytkowniku ' + user.tag).setThumbnail(user.displayAvatarURL(client.ImageURLOptions)).attachFiles(attachment).setImage('attachment://ui.png'));
	}
}

module.exports.config = {
	name: 'userinfo',
	permissionLevel: 1,
	aliases: ['ui'],
	filename: 'tools/userinfo.js',
	disabled: false,
	description: {
		pl: "Wyświetla informacje o wybranym użytkowniku",
		en: "Displays information about selected user"
	},
	ussuage: {
		pl: "{prefix}userinfo [użytkownik]",
		en: "{prefix}userinfo [użytkownik]"
	}
}