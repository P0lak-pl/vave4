const Discord = require("discord.js")
const fetch = require("node-fetch")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/meme', 'pl')
    const data = await fetch(`http://memapi.glitch.me/`).then(res => res.json());
    let att = new Discord.MessageAttachment(data.zdj, "image.png")
    let embed = lang.buildEmbed(message, [
        {
            "from": "desc",
            "to": data.title
        }
    ])
    .attachFiles(att)
    .setImage("attachment://image.png")
    message.channel.send(embed)
}

module.exports.config = {
    name: 'meme',
	permissionLevel: 1,
	aliases: ['mem'],
	filename: 'fun/meme.js',
	disabled: false,
	description: {
		pl: "Wyświetla losowy mem",
		en: "Displays random meme"
	},
	ussuage: {
		pl: "{prefix}meme",
		en: "{prefix}meme"
	}
}