const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/cytat', 'pl')
    const data = await fetch(`https://rezzuapi.glitch.me/cytaty`).then(response => response.json());
    let embed = lang.buildEmbed(message, [
        {
            "from": "cytat",
            "to": data.cytat
        }
    ])
	message.channel.send(embed)
}

module.exports.config = {
    name: 'cytat',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/cytat.js',
	disabled: false,
	description: {
		pl: "Wyświetla losowy cytat",
		en: "Displays a random quote"
	},
	ussuage: {
		pl: "{prefix}cytat",
		en: "{prefix}cytat"
	}
}