const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/pixelate', 'pl')
    const user = message.mentions.members.first() || message.author
    let att = new Discord.MessageAttachment(`https://some-random-api.ml/canvas/pixelate?avatar=${user.displayAvatarURL({ dynamic: false, format: "png" })}`, "image.png")
    let embed = lang.buildEmbed(message)
    .attachFiles(att)
    .setImage("attachment://image.png")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'pixelate',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/pixelate.js',
	disabled: false,
	description: {
		pl: "Pikselyzuje Twój avatar",
		en: "Pixelizes your avatar"
	},
	ussuage: {
		pl: "{prefix}pixelate [@użytkownik]",
		en: "{prefix}pixelate [@user]"
	}
}