const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/captcha', 'pl')
    const tekst = args.join("+")
    let att = new Discord.MessageAttachment(`https://api.no-api-key.com/api/v2/recaptcha?text=${tekst}`, "image.png")
    if (!tekst) return message.channel.send("Please specify args!")
    let embed = lang.buildEmbed(message)
    .attachFiles(att)
    .setImage("attachment://image.png")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'captcha',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/captcha.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Tworzy fake captchę",
		en: "Creates captcha"
	},
	ussuage: {
		pl: "{prefix}captcha [tekst]",
		en: "{prefix}captcha [text]"
	}
}
