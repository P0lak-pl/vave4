const fetch = require('node-fetch');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('mc', 'pl');

	const data = await fetch(`https://mcapi.us/server/status?ip=${args[0]}`).then(response => response.json());

	const banner = new Discord.MessageAttachment(`http://status.mclive.eu/${args[0]}/${args[0]}/25565/banner.png`, 'banner.png')
	const favicon = new Discord.MessageAttachment(new Buffer.from(data.favicon.split(',')[1], 'base64'), 'favicon.png');

	const embed = lang.buildEmbed(message, [
		{
			"from": "online",
			"to": client.functions.resolveBool('pl', 'YesNo', data.online)
		},
		{
			"from": "playersOnline",
			"to": data.players.now
		},
		{
			"from": "playersMax",
			"to": data.players.max
		},
		{
			"from": "serverName",
			"to": data.server.name
		},
		{
			"from": "onlineFor",
			"to": /*data.duration*/ "*Chwilowo nie działa*"
		}
	])
		.attachFiles(banner)
		.attachFiles(favicon)
		.setImage('attachment://banner.png')
		.setThumbnail('attachment://favicon.png');
	
	message.channel.send(embed);
}

module.exports.config = {
	name: 'mc',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/mc.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Pokazuje informacje o serwerze Minecraft",
		en: "Shows information about Minecraft server"
	},
	ussuage: {
		pl: "{prefix}mc <IP serwera>",
		en: "{prefix}mc <Server IP>"
	}
}
