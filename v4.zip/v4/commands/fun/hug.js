const Discord = require("discord.js")
const fetch = require("node-fetch")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/hug', 'pl')
    const user = message.mentions.members.first()
    const data = await fetch("https://some-random-api.ml/animu/hug").then(res => res.json())
    const att = new Discord.MessageAttachment(data.link, "image.gif")
    let embed = lang.buildEmbed(message, [
        {
            "from": "messageauthor",
            "to": message.author
        },
        {
            "from": "target",
            "to": user
        }
    ])
    .attachFiles(att)
    .setImage("attachment://image.gif")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'hug',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/hug.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Przytula użytkownika",
		en: "Hugs the user"
	},
	ussuage: {
		pl: "{prefix}hug [@użytkownik]",
		en: "{prefix}hug [@user]"
	}
}
