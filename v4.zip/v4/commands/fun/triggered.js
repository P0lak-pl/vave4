const fetch = require('node-fetch');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('_/_wait', 'pl');

	message.channel.send(lang.buildEmbed(message).setTitle('Change my mind')).then(async(embed) => {
		const response = await fetch('https://scriptchip.cf/v2/imageGeneration/triggered?avatar=' + message.author.displayAvatarURL(client.ImageURLOptions), {
			method: 'get',
			headers: {'Authorization': 'ksc8FCqegfPaTBPTTKaq2GqfiKWrSZ9VKCKVVNSU'}
		});

		const arrayBuffer = await response.arrayBuffer();
		const buffer = Buffer.from(arrayBuffer);

		const attachment = new Discord.MessageAttachment(buffer, 'triggered.gif'); 

		let embed2 = client.functions.done('pl', '', message)
			.setFooter('Powered by scriptchip.cf | ' + client.footer)
			.attachFiles(attachment)
			.setImage('attachment://triggered.gif');
		
		message.channel.send(embed2);
		embed.delete();
	});
}

module.exports.config = {
	name: 'triggered',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/triggered.js',
	disabled: false,
	description: {
		pl: "Tworzy GIF \"Triggered\" z avatarem",
		en: "Creates \"Triggered\" GIF with avatar"
	},
	ussuage: {
		pl: "{prefix}triggered [użytkownik]",
		en: "{prefix}triggered [user]"
	}
}