const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/cat', 'pl')
    const data = await fetch(`https://some-random-api.ml/img/cat`).then(response => response.json());
    let embed = lang.buildEmbed(message, [])
    embed.setImage(data.link)
    message.channel.send(embed)
}

module.exports.config = {
    name: 'cat',
	  permissionLevel: 1,
	  aliases: [],
	  filename: 'fun/cat.js',
	  disabled: false,
	  description: {
	  	pl: "Wyświetla losowy obrazek kota",
	  	en: "Displays a random cat image"
	  },
	  ussuage: {
	  	pl: "{prefix}cat",
	  	en: "{prefix}cat"
	  }
}
