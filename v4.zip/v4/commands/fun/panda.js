const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/panda', 'pl')
    const data = await fetch(`https://some-random-api.ml/img/panda`).then(response => response.json());
    let embed = lang.buildEmbed(message, [])
    embed.setImage(data.link)
    message.channel.send(embed)
}

module.exports.config = {
    name: 'panda',
	  permissionLevel: 1,
	  aliases: [],
	  filename: 'fun/panda.js',
	  disabled: false,
	  description: {
	  	pl: "Wyświetla losowy obrazek pandy",
	  	en: "Displays a random panda image"
	  },
	  ussuage: {
	  	pl: "{prefix}panda",
	  	en: "{prefix}panda"
	  }
}
