const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/dog', 'pl')
    const data = await fetch(`https://some-random-api.ml/img/dog`).then(response => response.json());
    let embed = lang.buildEmbed(message, [])
    embed.setImage(data.link)
    message.channel.send(embed)
}

module.exports.config = {
    name: 'dog',
	  permissionLevel: 1,
	  aliases: [],
	  filename: 'fun/dog.js',
	  disabled: false,
	  description: {
	  	pl: "Wyświetla losowy obrazek psa",
	  	en: "Displays a random dog image"
	  },
	  ussuage: {
	  	pl: "{prefix}dog",
	  	en: "{prefix}dog"
	  }
}
