const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/koala', 'pl')
    const data = await fetch(`https://some-random-api.ml/img/koala`).then(response => response.json());
    let embed = lang.buildEmbed(message, [])
    embed.setImage(data.link)
    message.channel.send(embed)
}

module.exports.config = {
    name: 'koala',
	  permissionLevel: 1,
	  aliases: [],
	  filename: 'fun/koala.js',
	  disabled: false,
	  description: {
	  	pl: "Wyświetla losowy obrazek koalii",
	  	en: "Displays a random koala image"
	  },
	  ussuage: {
	  	pl: "{prefix}koala",
	  	en: "{prefix}koala"
	  }
}
