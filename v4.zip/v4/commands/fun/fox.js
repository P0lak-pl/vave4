const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/fox', 'pl')
    const data = await fetch(`https://some-random-api.ml/img/fox`).then(response => response.json());
    let embed = lang.buildEmbed(message, [])
    embed.setImage(data.link)
    message.channel.send(embed)
}

module.exports.config = {
    name: 'fox',
	  permissionLevel: 1,
	  aliases: [],
	  filename: 'fun/cat.js',
	  disabled: false,
	  description: {
	  	pl: "Wyświetla losowy obrazek lisa",
	  	en: "Displays a random fox image"
	  },
	  ussuage: {
	  	pl: "{prefix}fox",
	  	en: "{prefix}fox"
	  }
}
