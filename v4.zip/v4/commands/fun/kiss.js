const Discord = require("discord.js")
const fetch = require("node-fetch")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/kiss', 'pl')
    const user = message.mentions.members.first()
    const data = await fetch("https://no-api-key.com/api/v1/kiss").then(res => res.json())
    const att = new Discord.MessageAttachment(data.image, "image.gif")
    let embed = lang.buildEmbed(message, [
        {
            "from": "messageauthor",
            "to": message.author
        },
        {
            "from": "target",
            "to": user
        }
    ])
    .attachFiles(att)
    .setImage("attachment://image.gif")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'kiss',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/kiss.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Całuje użytkownika",
		en: "Kiss the user"
	},
	ussuage: {
		pl: "{prefix}kiss [@użytkownik]",
		en: "{prefix}kiss [@user]"
	}
}
