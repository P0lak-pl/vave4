const fetch = require('node-fetch');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	throw new Error('Test');

	let user1 = message.author;
	let user2 = client.users.cache.get(message.guild.members.cache.array()[Math.floor(Math.random() * message.guild.members.cache.array().length)].id);
	
	if(args.length == 2) {
		if(client.functions.getUserFromMention(args[0], client)) user1 = client.functions.getUserFromMention(args[0], client);
		if(client.functions.getUserFromMention(args[1], client)) user2 = client.functions.getUserFromMention(args[1], client);
	} else if(args.length == 1) {
		if(client.functions.getUserFromMention(args[0], client)) user2 = client.functions.getUserFromMention(args[0], client);
	}
	
	
	const response = await fetch('https://scriptchip.cf/v2/imageGeneration/ship?avatar1=' + user1.displayAvatarURL(client.ImageURLOptions) + '&avatar2=' + user2.displayAvatarURL(client.ImageURLOptions), {
		method: 'get',
		headers: {'Authorization': 'ksc8FCqegfPaTBPTTKaq2GqfiKWrSZ9VKCKVVNSU'}
	});

	const arrayBuffer = await response.arrayBuffer();
	const buffer = Buffer.from(arrayBuffer);

	const attachment = new Discord.MessageAttachment(buffer, 'ship.png'); 
	const random = Math.floor(Math.random() * 100) + 1;

	const embed = new client.LanguageHandler('fun/ship', 'pl').buildEmbed(message, [
		{
			"from": "user1",
			"to": user1.username
		},
		{
			"from": "user2",
			"to": user2.username
		},
		{
			"from": "bar",
			"to": client.functions.barGenerator(random)
		},
		{
			"from": "joined",
			"to": user1.username.slice(0, Math.ceil(user1.username.length / 2)) + user2.username.slice(Math.ceil(user2.username.length / 2), user2.username.length)
		},
		{
			"from": "percentage",
			"to": random
		}
	]).attachFiles(attachment).setImage('attachment://ship.png');

	message.channel.send(embed);
}

module.exports.config = {
	name: 'ship',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/ship.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Łączy 2 osoby węzłem miłości ( ͡° ͜ʖ ͡°)",
		en: "Connects 2 people with knot of love ( ͡° ͜ʖ ͡°)"
	},
	ussuage: {
		pl: "{prefix}ship [użytkownik 1] [użytkownik 2]",
		en: "{prefix}ship [user 1] [user 2]"
	}
}
