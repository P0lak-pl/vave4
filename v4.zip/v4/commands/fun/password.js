const Discord = require("discord.js")
const fetch = require("node-fetch")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/password', 'pl')
    const liczba = Math.floor(Math.random() * 14) + 6
    const data = await fetch(`https://no-api-key.com/api/v1/password?length=${liczba}`).then(res => res.json())
    let embed = lang.buildEmbed(message, [
        {
            "from": "pass",
            "to": data.password
        },
        {
            "from": "length",
            "to": data.length
        }
    ])
	message.channel.send(embed)
}

module.exports.config = {
    name: 'password',
	permissionLevel: 1,
	aliases: ['pwd', 'haslo'],
	filename: 'fun/password.js',
	disabled: false,
	description: {
		pl: "Generuje losowe hasło",
		en: "Generates random password"
	},
	ussuage: {
		pl: "{prefix}password",
		en: "{prefix}password"
	}
}