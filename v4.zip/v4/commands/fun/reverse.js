const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/reverse', 'pl')
    const tekst = args.join(" ")
    let embed = lang.buildEmbed(message, [
        {
            "from": "reversed",
            "to": tekst.split("").reverse().join("")
        }
	])
	message.channel.send(embed)
}

module.exports.config = {
    name: 'reverse',
	permissionLevel: 1,
	aliases: ['odwroc', 'odwróć'],
	filename: 'fun/reverse.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Odwraca tekst",
		en: "Inverts text"
	},
	ussuage: {
		pl: "{prefix}reverse [tekst]",
		en: "{prefix}reverse [text]"
	}
}
