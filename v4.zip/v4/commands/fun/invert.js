const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/invert', 'pl')
    const user = message.mentions.members.first() || message.author
    let att = new Discord.MessageAttachment(`https://api.no-api-key.com/api/v2/invert?image=${user.displayAvatarURL({ dynamic: false, format: "png" })}`, "image.png")
    let embed = lang.buildEmbed(message)
    .attachFiles(att)
    .setImage("attachment://image.png")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'invert',
	permissionLevel: 1,
	aliases: ['inv'],
	filename: 'fun/invert.js',
	disabled: false,
	description: {
		pl: "Odwraca kolory Twojego avataru",
		en: "Inverts your avatar colors"
	},
	ussuage: {
		pl: "{prefix}invert [@użytkownik]",
		en: "{prefix}invert [@user]"
	}
}
