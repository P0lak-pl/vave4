const Discord = require("discord.js");
const fetch = require('node-fetch');

module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/pokemon', 'pl')
	
	const data = await fetch(`https://some-random-api.ml/pokedex?pokemon=${encodeURI(args.join(' '))}`).then(res => res.json());
	
	/*if(data.error && data.error == 'Sorry, I could not find that pokemon') {
		message.channel.send(lang.buildEmbed(message)[0]);
		return;
	}*/

	//console.log(data);
	
	let types = '';
	let species = '';
	let abilities = '';
	let height = '';
	let weight = '';
	let evolutionLine = '';

	data.type.forEach(type => types += `\`${type}\`, `);
	data.species.forEach(specie => species += `\`${specie}\`, `);
	data.abilities.forEach(ability => abilities += `\`${ability}\`, `);
	height = data.height.split(' ')[0];
	weight = data.weight.split(' ')[0];
	data.family.evolutionLine.forEach((ev, i) => evolutionLine += `${i + 1}. ${ev}\n`);

	message.channel.send(lang.buildEmbed(message, [
		{
			"from": "name",
			"to": client.functions.capitalize(data.name)
		},
		{
			"from": "types",
			"to": types.slice(0, -2)
		},
		{
			"from": "species",
			"to": species.slice(0, -2)
		},
		{
			"from": "abilities",
			"to": abilities.slice(0, -2)
		},
		{
			"from": "height",
			"to": height
		},
		{
			"from": "weight",
			"to": weight
		},
		{
			"from": "hp",
			"to": data.stats.hp
		},
		{
			"from": "attack",
			"to": data.stats.attack
		},
		{
			"from": "speed",
			"to": data.stats.speed
		},
		{
			"from": "evolutionStage",
			"to": data.family.evolutionStage
		},
		{
			"from": "evolutionLine",
			"to": evolutionLine
		}
	])[1].attachFiles(new Discord.MessageAttachment(data.sprites.animated, 'sprite.gif')).setThumbnail('attachment://sprite.gif'))
}

module.exports.config = {
    name: 'pokemon',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/pokemon.js',
	disabled: false,
	description: {
		pl: "Pokazuje informacje o Pokémon'ie",
		en: "Show information about Pokémon"
	},
	ussuage: {
		pl: "{prefix}pokemon <nazwa Pokémon'a>",
		en: "{prefix}pokemon <Pokémon name>"
	}
}