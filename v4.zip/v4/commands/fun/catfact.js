const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/catfact', 'pl')
    const data = await fetch(`https://rezzuapi.glitch.me/faktyokotach`).then(response => response.json());
    let embed = lang.buildEmbed(message, [
        {
            "from": "catfact",
            "to": data.kot
        }
    ])
    message.channel.send(embed)
}

module.exports.config = {
    name: 'catfact',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/catfact.js',
	disabled: false,
	description: {
		pl: "Wyświetla losowy fakt o kotach",
		en: "Displays a random fact about cats"
	},
	ussuage: {
		pl: "{prefix}catfact",
		en: "{prefix}catfact"
	}
}
