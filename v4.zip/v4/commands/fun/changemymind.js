const fetch = require('node-fetch');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('_wait', 'pl');

	message.channel.send(lang.buildEmbed(message).setTitle('Change my mind')).then(async(embed) => {
		const response = await fetch('https://scriptchip.cf/v2/imageGeneration/changemymind?text=' + encodeURI(args.join(' ')), {
			method: 'get',
			headers: {'Authorization': 'ksc8FCqegfPaTBPTTKaq2GqfiKWrSZ9VKCKVVNSU'}
		});

		const arrayBuffer = await response.arrayBuffer();
		const buffer = Buffer.from(arrayBuffer);

		const attachment = new Discord.MessageAttachment(buffer, 'changemymind.png'); 

		let embed2 = client.functions.done('pl', '', message)
			.setFooter('Powered by scriptchip.cf | ' + client.footer)
			.attachFiles(attachment)
			.setImage('attachment://changemymind.png');
		
		message.channel.send(embed2);
		embed.delete();
	});
}

module.exports.config = {
	name: 'changemymind',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/changemymind.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Tworzy mem \"Change my mind\"",
		en: "Creates \"Change my mind\" meme"
	},
	ussuage: {
		pl: "{prefix}changemymind <tekst>",
		en: "{prefix}changemymind <text>"
	}
}
