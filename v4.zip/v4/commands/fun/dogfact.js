const Discord = require("discord.js")
const fetch = require('node-fetch');
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/dogfact', 'pl')
    const data = await fetch(`https://rezzuapi.glitch.me/faktyopsach`).then(response => response.json());
    let embed = lang.buildEmbed(message, [
        {
            "from": "dogfact",
            "to": data.pies
        }
    ])
	message.channel.send(embed)
}

module.exports.config = {
    name: 'dogfact',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/dogfact.js',
	disabled: false,
	description: {
		pl: "Wyświetla losowy fakt o psach",
		en: "Displays a random fact about dogs"
	},
	ussuage: {
		pl: "{prefix}dogfact",
		en: "{prefix}dogfact"
	}
}
