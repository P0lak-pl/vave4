const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/trump', 'pl')
    const tekst = args.join("+")
    const att = new Discord.MessageAttachment(`https://api.no-api-key.com/api/v2/trump?message=${tekst}`, "image.png")
    let embed = lang.buildEmbed(message)
    .attachFiles(att)
    .setImage("attachment://image.png")
	message.channel.send(embed)
}

module.exports.config = {
    name: 'trump',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/captcha.js',
	disabled: false,
        args: 1,
	description: {
		pl: "Tworzy fake tweet pisany przez Donalda Trumpa",
		en: "Creates a fake tweet by Donald Trump"
	},
	ussuage: {
		pl: "{prefix}trump [tekst]",
		en: "{prefix}trump [text]"
	}
}
