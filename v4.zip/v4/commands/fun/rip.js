const fetch = require('node-fetch');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => { 
	const lang = new client.LanguageHandler('_/_wait', 'pl');

	message.channel.send(lang.buildEmbed(message).setTitle('R.I.P')).then(async(embed) => {
		const response = await fetch('https://scriptchip.cf/v2/imageGeneration/rip?avatar=' + message.author.displayAvatarURL({ format: 'png' }), {
			method: 'get',
			headers: {'Authorization': 'ksc8FCqegfPaTBPTTKaq2GqfiKWrSZ9VKCKVVNSU'}
		}); 

		const arrayBuffer = await response.arrayBuffer();
		const buffer = Buffer.from(arrayBuffer);

		const attachment = new Discord.MessageAttachment(buffer, 'rip.png'); 

		let embed2 = client.functions.done('pl', '', message)
			.setFooter('Powered by scriptchip.cf | ' + client.footer)
			.attachFiles(attachment)
			.setImage('attachment://rip.png');
		
		message.channel.send(embed2);
		embed.delete();
	});
}

module.exports.config = {
	name: 'rip',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/rip.js',
	disabled: false,
	description: {
		pl: "Tworzy nagrobek z avatarem",
		en: "Creates grave with avatar"
	},
	ussuage: {
		pl: "{prefix}rip [użytkownik]",
		en: "{prefix}rip [user]"
	}
}
