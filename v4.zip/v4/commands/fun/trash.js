const Discord = require("discord.js")
module.exports.run = async (client, message, args, guildConfig) => {
    const lang = new client.LanguageHandler('fun/trash', 'pl')
    const user = message.mentions.users.first() || message.author
    const att = new Discord.MessageAttachment(`https://api.no-api-key.com/api/v2/trash?image=${user.displayAvatarURL({ dynamic: false, format: "png" })}`, "image.png")
    let embed = lang.buildEmbed(message)
    .attachFiles(att)
    .setImage("attachment://image.png")
    message.channel.send(embed)
}

module.exports.config = {
    name: 'trash',
	permissionLevel: 1,
	aliases: [],
	filename: 'fun/trash.js',
	disabled: false,
	description: {
	    pl: "Wyrzuca avatar użytkownika do kosza",
	    en: "Throws the user avatar to the trash"
	},
	ussuage: {
	  	pl: "{prefix}trash [@użytkownik]",
	  	en: "{prefix}trash [@user]"
	}
}
