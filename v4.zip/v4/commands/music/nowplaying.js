const createBar = require('string-progressbar');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('music/nowplaying', 'pl');
	const serverQueue = client.queue.get(message.guild.id);
	
	if(!serverQueue || !serverQueue.songs || !serverQueue.songs.length) {
		message.channel.send(lang.buildEmbed(message)[0]);
		return;
	}

	const song = serverQueue.songs[0];
    const seek = (serverQueue.connection.dispatcher.streamTime - serverQueue.connection.dispatcher.pausedTime) / 1000;
	const left = song.duration - seek;

	let remaining = '';
	if(song.duration > 0) remaining = new Date(left * 1000).toISOString().substr(11, 8);
	else remaining = '🔴 LIVE';
	let data = await require('ytdl-core').getInfo(song.url);

	const embed = lang.buildEmbed(message, [
		{
			"from": "title",
			"to": song.title
		},
		{
			"from": "url",
			"to": song.url
		},
		{
			"from": "author",
			"to": message.author.id
		},
		{
			"from": "title",
			"to": song.author.id
		},
		{
			"from": "progress",
			"to": new Date(seek * 1000).toISOString().substr(11, 8) + "[" + createBar((song.duration == 0 ? seek : song.duration), seek, 20)[0] + "]" + (song.duration == 0 ? " ◉ LIVE" : new Date(song.duration * 1000).toISOString().substr(11, 8))
		},
		{
			"from": "remaining",
			"to": remaining
		}
	])[1];

	embed.attachFiles(new Discord.MessageAttachment(data.videoDetails.thumbnail.thumbnails[data.videoDetails.thumbnail.thumbnails.length - 1].url, 'thumbnail.png'))
	embed.setThumbnail('attachment://thumbnail.png');

	message.channel.send(embed);
}

module.exports.config = {
	name: 'nowplaying',
	permissionLevel: 1,
	aliases: ['np'],
	filename: 'music/nowplaying.js',
	disabled: false,
	description: {
		pl: "Wyświetla aktualnie graną piosenkę",
		en: "Displays cuurent song"
	},
	ussuage: {
		pl: "{prefix}nowplaying",
		en: "{prefix}nowplaying"
	}
}