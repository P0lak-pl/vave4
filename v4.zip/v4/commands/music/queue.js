const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('music/queue', 'pl').getProps();
	const queue = client.queue.get(message.guild.id).songs;

	const generateEmbed = start => {
		const current = queue.slice(start, start + 10)

		const embed = new Discord.MessageEmbed()
			.setTitle(lang.title)
		current.forEach((g, i) => embed.addField('\u200B', `**${start + i + 1}.** [${g.title}](${g.url} '${g.title}')`))
		return embed
	}

	const author = message.author

	message.channel.send(generateEmbed(0)).then(message => {
		if (queue.length <= 10) return
		message.react('➡️')
		const collector = message.createReactionCollector(
			(reaction, user) => ['⬅️', '➡️'].includes(reaction.emoji.name) && user.id === author.id,
			{time: 60000}
		)

		let currentIndex = 0
		collector.on('collect', reaction => {
			message.reactions.removeAll().then(async () => {
				reaction.emoji.name === '⬅️' ? currentIndex -= 10 : currentIndex += 10
				message.edit(generateEmbed(currentIndex))
				if (currentIndex !== 0) await message.react('⬅️')
				if (currentIndex + 10 < queue.length) message.react('➡️')
			})
		})
	})
}

module.exports.config = {
	name: 'queue',
	permissionLevel: 1,
	aliases: [],
	filename: 'music/queue.js',
	disabled: false,
	description: {
		pl: "Pokazuje aktualną kolejkę",
		en: "Shows current queue"
	},
	ussuage: {
		pl: "{prefix}queue",
		en: "{prefix}queue"
	}
}