const ytdl = require("ytdl-core");
const Discord = require("discord.js");
const lib = require("../../lib/music");
const YouTubeAPI = require("simple-youtube-api");
const youtube = new YouTubeAPI(require('../../config.json').youtubeToken);

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('music/search', 'pl');

	const serverQueue = client.queue.get(message.guild.id);
	const voiceChannel = message.member.voice.channel;
	if(!voiceChannel) {
		message.channel.send(lang.buildEmbed(message)[0]);
		return;
	}
	
	const permissions = voiceChannel.permissionsFor(message.client.user);
	
	if (!permissions.has("CONNECT") || !permissions.has("SPEAK")) {
		message.channel.send(lang.buildEmbed(message)[1]);
		return;
	}
	
	const result = await youtube.searchVideos(args.join(" "), 1);
	const url = "https://youtube.com/watch?v=" + result[0].id;

	const songInfo = await ytdl.getInfo(url);
	const song = {
		title: songInfo.videoDetails.title,
		url: songInfo.videoDetails.video_url,
		duration: songInfo.videoDetails.lengthSeconds,
		author: message.author,
		youtube: true
	};
	
	//console.log(songInfo);
	
	if (!serverQueue) {
		const queueContruct = {
			textChannel: message.channel,
			voiceChannel: voiceChannel,
			connection: null,
			songs: [],
			volume: 5,
			playing: true,
			loop: false
		};

		client.queue.set(message.guild.id, queueContruct);

		queueContruct.songs.push(song);

		try {
			var connection = await voiceChannel.join();
			//console.log(connection);
			queueContruct.connection = connection;
			lib.play(message.guild, queueContruct.songs[0], client.queue, message);
			//console.log(queue.get(message.guild.id).songs)
		} catch (err) {
			console.log(err);
			queue.delete(message.guild.id);
			return message.channel.send(err);
		}
	} else {
		serverQueue.songs.push(song);
		message.channel.send(lang.buildEmbed(message, [
			{
				"from": "song",
				"to": song.title
			}
		])[2]);
	}
}

module.exports.config = {
	name: 'play',
	permissionLevel: 1,
	aliases: [],
	filename: 'music/play.js',
	disabled: false,
	description: {
		pl: "Przeszukuję YouTube i dodaje wybraną piosenkę do kolejki",
		en: "Searches YouTube and adds selected songs to queue"
	},
	ussuage: {
		pl: "{prefix}play <nazwa piosenki w serwisie YouTube>",
		en: "{prefix}play <song name in YouTube>"
	}
}