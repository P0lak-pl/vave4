const db = require('quick.db');
const Canvacord = require('canvacord');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const lang = new client.LanguageHandler('levels/leaderboard', 'pl');

	const levels = db
		.all()
		.filter((data) => data.ID.startsWith(`level_${message.guild.id}_`))
		.sort((a, b) => b.data - a.data);
		
	let every = db
		.all()
		.filter(i => i.ID.startsWith(`xptotal_${message.guild.id}_`))
		.sort((a,b) => b.data - a.data);
	var rank = every.map(x => x.ID).indexOf(`xptotal_${message.guild.id}_${message.author.id}`) + 1;
	
	const generateEmbed = start => {
		const current = levels.slice(start, start + 10)

		const embed = lang.buildEmbed(message);
		current.forEach((g, i) => embed.addField('\u200B', `**${start + i + 1}.** ${client.users.cache.get(g.ID.replace(`level_${message.guild.id}_`, '')).username} - ${g.data}`))
		return embed
	}

	const author = message.author

	message.channel.send(generateEmbed(0)).then(message => {
		if (levels.length <= 10) return
		message.react('➡️')
		const collector = message.createReactionCollector(
			(reaction, user) => ['⬅️', '➡️'].includes(reaction.emoji.name) && user.id === author.id,
			{time: 60000}
		)

		let currentIndex = 0

		collector.on('collect', reaction => {
			message.reactions.removeAll().then(async () => {
				reaction.emoji.name === '⬅️' ? currentIndex -= 10 : currentIndex += 10
				message.edit(generateEmbed(currentIndex))
				if (currentIndex !== 0) await message.react('⬅️')
				if (currentIndex + 10 < levels.length) message.react('➡️')
			})
		})
	})
}

module.exports.config = {
	name: 'leaderboard',
	permissionLevel: 1,
	aliases: ['lb'],
	filename: 'levels/leaderboard.js',
	disabled: false,
	description: {
		pl: "Wyświetla TOP serwera w poziomach",
		en: "Displays TOP of the server in levels"
	},
	ussuage: {
		pl: "{prefix}leaderboard",
		en: "{prefix}leaderboard"
	}
}