const db = require('quick.db');
const Canvacord = require('canvacord');
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	var user = message.mentions.users.first() || message.author;
	var level = db.get(`level_${message.guild.id}_${user.id}`) || 0;
	let xp = db.get(`xp_${message.guild.id}_${user.id}`) || 0;
	let xpNeeded = level * 500 + 500;
	let every = db
		.all()
		.filter(i => i.ID.startsWith(`xptotal_${message.guild.id}_`))
		.sort((a,b) => b.data - a.data);
	var rank = every.map(x => x.ID).indexOf(`xptotal_${message.guild.id}_${user.id}`) + 1;
	
	let card = new Canvacord.Rank()
		.setAvatar(user.displayAvatarURL({ format: 'png' }))
		.setCurrentXP(xp)
		.setRequiredXP(xpNeeded)
		.setLevel(level)
		.setRank(rank)
		.setStatus(user.presence.status)
		.setProgressBar(["DARKBLUE", "BLUE"], "GRADIENT")
		.setUsername(user.username)
		.setDiscriminator(user.discriminator);
	
	card.build().then(data => {
		return message.channel.send(new Discord.MessageAttachment(data, 'rank.png'))
	});
}

module.exports.config = {
	name: 'rank',
	permissionLevel: 1,
	aliases: [],
	filename: 'levels/rank.js',
	disabled: false,
	description: {
		pl: "Wyświetla poziom wybranego użytkownika",
		en: "Displays level of selected user"
	},
	ussuage: {
		pl: "{prefix}rank [@użytkownik]",
		en: "{prefix}rank [@user]"
	}
}
