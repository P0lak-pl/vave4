const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	if(!message.member.hasPermission('ADMINISTRATOR')) {
		const lang = new client.LanguageHandler('_/_err_perms', 'pl');
		const embed = lang.buildEmbed(message, [
			{
				"from": "perms",
				"to": "Administrator"
			}
		]);

		message.channel.send(embed);
		return;
	}

	const lang = new client.LanguageHandler('moderation/config', 'pl');

	message.channel.send(lang.buildEmbed(message)[0]);

	const filter = m => m.author.id === message.author.id;
	message.channel.awaitMessages(filter, {
		max: 1,
		time: 60000
	}).then(collected => {
		collected.delete(15000);
		const msg = collected.first().content;
		
		if(msg == '1') {

			message.channel.send(lang.buildEmbed(message, [{
				"from": "setting",
				"to": "Prefix"
			}])[1]);

			message.channel.awaitMessages(filter, {
				max: 1,
				time: 60000
			 }).then(collected => {
				collected.delete(15000);
				const value = collected.first().content;
				
				message.channel.send(lang.buildEmbed(message, [{
					"from": "setting",
					"to": "Prefix",
				},
				{
					"from": "value",
					"to": value
				}])[2]);

				message.channel.awaitMessages(filter, {
					max: 1,
					time: 60000
				 }).then(collected => {
					collected.delete(15000);
					const msg = collected.first().content;

					if(msg == 'y') {
						try {
							client.settings.set(message.guild.id, value, 'prefix');
							message.channel.send(lang.buildEmbed(message, [{
								"from": "setting",
								"to": "Prefix",
							},
							{
								"from": "value",
								"to": msg
							}])[3]);
						} catch(err) {
							message.channel.send(lang.buildEmbed(message)[4]);
						}
					} else {
						message.channel.send(lang.buildEmbed(message)[5]);
					}
			
				}).catch(err => {
					// ToDo: Time exceeded
				});
		
			}).catch(err => {
				// ToDo: Time exceeded
			});
		}

	}).catch(err => {
		// ToDo: Time exceeded
	});
}

module.exports.config = {
	name: 'config',
	permissionLevel: 2,
	aliases: [],
	filename: 'moderation/config.js',
	disabled: false,
	description: {
		pl: "Otwiera menu konfiguracji serwerowej",
		en: "Opens server's configuration menu"
	},
	ussuage: {
		pl: "{prefix}config",
		en: "{prefix}config"
	}
}