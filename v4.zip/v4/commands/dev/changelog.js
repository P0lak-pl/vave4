const chalk = require('chalk');
const Discord = require('discord.js');
const logSymbols = require('log-symbols');
const { inspect } = require('util');

let allowed = [
	'396286593033437185',
	'406085770018029568'
];

module.exports.run = async(client, message, args, guildConf) => {
	client.channels.cache.get('699922347846533180').send(new Discord.MessageEmbed()
		.setTitle(`\`> Update ${args[0]}\``)
		.setDescription(`\`\`\`diff\n${args.slice(1).join(' ').split('\\n').join('\n')}\`\`\``)
		.setFooter(client.footer));
}

module.exports.config = {
	name: 'changelog',
	permissionLevel: 5,
	aliases: [],
	filename: 'dev/changelog.js',
	disabled: false,
	description: {
		pl: "Wywołuje podany kod JavaScript",
		en: "Evaluates given JavaScript code"
	},
	ussuage: {
		pl: "{prefix}eval <Kod JavaScript>",
		en: "{prefix}eval <JavaScript code>"
	}
}
