const db = require('quick.db');
const moment = require('moment');

module.exports.run = async(client, message, args, guildConf) => {
	if(client.functions.getUserFromMention(args[1], client)) {
		var user = client.functions.getUserFromMention(args[1], client);
	} else {
		return message.channel.send(new client.LanguageHandler('_/_err_userNotFound', 'pl').buildEmbed(message));
	}

	if(args[0] == 'add') {
		let reason = 'Nie podano powodu';
		if(args.slice(2).length) reason = args.slice(2).join(' ');

		db.set(`GlobalBan_${user.id}_reason`, reason);
		db.set(`GlobalBan_${user.id}_date`, new Date());
		db.set(`${user.id}_permissionLevel`, '0');

		message.channel.send(new client.LanguageHandler('dev/gban', 'pl').buildEmbed(message, [
			{
				"from": "user:name",
				"to": user.tag
			},
			{
				"from": "user:id",
				"to": user.id
			},
			{
				"from": "date",
				"to": moment(new Date()).format('DD.MM.YYYY HH:mm:ss')
			},
			{
				"from": "reason",
				"to": reason
			}
		])[0]);

		user.send(new client.LanguageHandler('dev/gban', 'pl').buildEmbed(message, [
			{
				"from": "author:name",
				"to": message.author.tag
			},
			{
				"from": "author:id",
				"to": message.author.id
			},
			{
				"from": "date",
				"to": moment(new Date()).format('DD.MM.YYYY HH:mm:ss')
			},
			{
				"from": "reason",
				"to": reason
			}
		])[1]);
	} else if(args[0] == 'remove') {
		let reason = 'Nie podano powodu';
		if(args.slice(2).length) reason = args.slice(2).join(' ');

		db.delete(`GlobalBan_${user.id}_reason`);
		db.delete(`GlobalBan_${user.id}_date`);
		db.set(`${user.id}_permissionLevel`, '1');

		message.channel.send(new client.LanguageHandler('dev/gban', 'pl').buildEmbed(message, [
			{
				"from": "user:name",
				"to": user.tag
			},
			{
				"from": "user:id",
				"to": user.id
			},
			{
				"from": "date",
				"to": moment(new Date()).format('DD.MM.YYYY HH:mm:ss')
			},
			{
				"from": "reason",
				"to": reason
			}
		])[2]);

		user.send(new client.LanguageHandler('dev/gban', 'pl').buildEmbed(message, [
			{
				"from": "author:name",
				"to": message.author.tag
			},
			{
				"from": "author:id",
				"to": message.author.id
			},
			{
				"from": "date",
				"to": moment(new Date()).format('DD.MM.YYYY HH:mm:ss')
			},
			{
				"from": "reason",
				"to": reason
			}
		])[3]);
	}
}

module.exports.config = {
	name: 'gban',
	permissionLevel: 5,
	args: 1,
	aliases: [],
	filename: 'dev/gban.js',
	disabled: false,
	description: {
		pl: "Dodaje użytkownika do listy globalnie zbanowanych",
		en: "Adds user to list of global banned"
	},
	ussuage: {
		pl: "{prefix}gban <@użytkownik/ID użytkownika>",
		en: "{prefix}gban <@user/user's ID>"
	}
}
