const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
	const generateEmbed = start => {
		const current = client.guilds.cache.array().slice(start, start + 10)
	
		const embed = new Discord.MessageEmbed()
			.setTitle('Guilds')
		current.forEach(async(g, i) => {
			let invite = await g.channels.cache.filter(c => c.type === 'text').find(x => x.position == 0).createInvite({ maxAge: 0, maxUses: 0 }).catch(console.log);
			embed.addField(g.name, `**${start + i + 1}.** \`${g.owner.tag} (${g.owner.id})\` | [Invite](${invite})`)
		})
		return embed
	}
	
	const author = message.author
	
	message.channel.send(generateEmbed(0)).then(message => {
		if (client.guilds.cache.array().length <= 10) return
		message.react('➡️')
		const collector = message.createReactionCollector(
			(reaction, user) => ['⬅️', '➡️'].includes(reaction.emoji.name) && user.id === author.id,
			{time: 60000}
		)
	
		let currentIndex = 0
		collector.on('collect', reaction => {
			message.reactions.removeAll().then(async () => {
				reaction.emoji.name === '⬅️' ? currentIndex -= 10 : currentIndex += 10
				message.edit(generateEmbed(currentIndex))
				if (currentIndex !== 0) await message.react('⬅️')
				if (currentIndex + 10 < client.guilds.cache.array().length) message.react('➡️')
			})
		})
	})
}

module.exports.config = {
	name: 'guilds',
	permissionLevel: 5,
	aliases: [],
	filename: 'dev/guilds.js',
	disabled: false,
	description: {
		pl: "Wywołuje podany kod JavaScript",
		en: "Evaluates given JavaScript code"
	},
	ussuage: {
		pl: "{prefix}eval <Kod JavaScript>",
		en: "{prefix}eval <JavaScript code>"
	}
}
