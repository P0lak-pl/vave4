const chalk = require('chalk');
const logSymbols = require('log-symbols');
const fs = require('fs');

let allowed = [
	'396286593033437185',
	'406085770018029568'
];

module.exports.run = async(client, message, args, guildConf) => {
	if(!allowed.includes(message.author.id)) {
		client.error('pl', 'Nie masz permisji do użycia tej komendy!\nWymagane permisje: `perms_global_programmist`');
		return;
	}

	if(!args.length) return message.channel.send(client.functions.error('pl', `Poprawne użycie: \`${guildConf.prefix}reload <nazwa komendy/alias komendy>\` - Przeładowuje wybraną komendę\n\`${guildConf.prefix}reload & <plik komendy>\` - Dodaje wybraną komendę do cache\n\`${guildConf.prefix}reload *\` - Przeładowuje wszystkie komendy\n\`${guildConf.prefix}reload @\` - Przeładowuje pliki statyczne\n\`${guildConf.prefix}reload %\` - Restartuje bota\n`, message));

	if(args[0] == '*') {
		try {
			client.commands.forEach(x => {
				delete require.cache[require.resolve(`../${x.config.filename}`)];
			});
			
			console.log(logSymbols.warning, 'Reloading all commands!');
	
			fs.readdir(__dirname, (err, files) => {
				if(err) throw err;
		
				let jsfile = files.filter(f => f.split('.').pop() === 'js') 
		
				if(jsfile.length <= 0) {
					return console.log(logSymbols.warning, 'No commands to load!');
				}
		
				files.forEach((file, i) => {
					const pull = require('../' + file);
			
					client.commands.set(pull.config.name, pull);
			
					console.log(logSymbols.info, `[${i + 1}] ${chalk.cyan(pull.config.filename)} loaded!`);
				});
			});
			
			console.log(logSymbols.success, 'Reloaded all commands!');
			message.channel.send(client.functions.done('pl', 'Przeładowano wszystkie komendy!', message));
			
			return;
		} catch(err) {
			message.channel.send(client.functions.error('pl', `\`\`\`${err.stack}\`\`\``, message));
			return;
		}
	} else if(args[0] == '&') {
		try {
			let props = require(`../${args[1]}.js`);
	
			client.commands.set(props.config.name, props);
	
			message.channel.send(client.functions.done('pl', `Dodano komendę\n\nNazwa: \`${props.config.name}\`\nAliasy: \`${props.config.aliases.join(', ')}\`\nPlik: \`${props.config.filename}\`\nWyłączona?: \`${client.functions.resolveBool('pl', 'YesNo', props.config.disabled)}\``, message))
			
			return;
		} catch(err) {
			message.channel.send(client.functions.error('pl', `\`\`\`${err.stack}\`\`\``, message));
			return;
		}
	} else if(args[0] == '@') {
		delete require.cache[require.resolve(`../lang/pl.json`)];
		delete require.cache[require.resolve(`../config.json`)];
		const lib = require('../../lib/index.js');
		lib.ClientFunction(client);

		message.channel.send(client.functions.done('pl', 'Przeładowano pliki statyczne', message));
		return;
	} else if(args[0] == '%') {
		message.channel.send(client.functions.done('pl', 'Restartowanie bota...', message));
		process.exit(0);
		return;
	}

	try {
		let command = client.commands.get(args[0]) || client.commands.find(x => x.config.aliases && x.config.aliases == args[0]);
		if(!command) {
			message.channel.send(client.functions.error('pl', `Nie znaleziono komendy o nazwie lub aliasie \`${args[0]}\``, message));
			return;
		}
		delete require.cache[require.resolve(`../${command.config.filename}`)];
		let newCommand = require(`../${command.config.filename}`);
		client.commands.set(newCommand.config.name, newCommand);

		message.channel.send(client.functions.done('pl', `Przeładowano komendę\n\nNazwa: \`${newCommand.config.name}\`\nAliasy: \`${newCommand.config.aliases.join(', ')}\`\nPlik: \`${newCommand.config.filename}\`\nWyłączona?: \`${client.functions.resolveBool('pl', 'YesNo', newCommand.config.disabled)}\``, message))
		console.log(logSymbols.info, 'Reloaded ' + newCommand.config.name + ' command!')
		return;
	} catch(err) {
		message.channel.send(client.functions.error('pl', `\`\`\`${err.stack}\`\`\``, message));
		return;
	}
}

module.exports.config = {
	name: 'reload',
	permissionLevel: 5,
	aliases: ['rl'],
	filename: 'dev/reload.js',
	disabled: false,
	description: {
		pl: "Przeładowuje komendy",
		en: "Reloades commands"
	},
	ussuage: {
		pl: "{prefix}reload <*/&/^/nazwa komendy>",
		en: "{prefix}reload <*/&/^/command name>"
	}
}