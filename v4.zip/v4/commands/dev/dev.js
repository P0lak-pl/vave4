const chalk = require('chalk');
const Discord = require('discord.js');
const logSymbols = require('log-symbols');
const { inspect } = require('util');

let allowed = [
	'396286593033437185',
	'406085770018029568'
];

module.exports.run = async(client, message, args, guildConf) => {
	if(args[0] == 'dbl') {
		if(args[1] == 'checkvote') {
			client.topgg.hasVoted(args[2]).then(voted => message.channel.send(`User \`${client.users.cache.get(args[2]).tag}\` ${voted ? 'has voted' : 'didn\'t vote'}`))
		}
	}
}

module.exports.config = {
	name: 'dev',
	permissionLevel: 5,
	aliases: [],
	filename: 'dev/dev.js',
	disabled: false,
	description: {
		pl: "Wywołuje podany kod JavaScript",
		en: "Evaluates given JavaScript code"
	},
	ussuage: {
		pl: "{prefix}eval <Kod JavaScript>",
		en: "{prefix}eval <JavaScript code>"
	}
}
