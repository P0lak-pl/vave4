const chalk = require('chalk');
const logSymbols = require('log-symbols');
const { inspect } = require('util');

let allowed = [
	'396286593033437185',
	'406085770018029568'
];

module.exports.run = async(client, message, args, guildConf) => {
	if(!allowed.includes(message.author.id)) {
		message.channel.send(client.functions.error('pl', 'Nie masz permisji do użycia tej komendy!\nWymagane permisje: `perms_global_programmist`', message));
		return;
	}

	if(!args.length) return message.channel.send(client.functions.error('pl', `Poprawne użycie: \`${guildConf.prefix}eval <Kod JavaScript>\` - Wykonuje podany skrypt`, message));

	const lang = new client.LanguageHandler('dev/eval', 'pl');

	try {
		const time = process.hrtime();
		let query = `const chalk = require('chalk'); const Discord = require('discord.js'); const logSymbols = require('log-symbols'); const moment = require('moment'); const db = require('quick.db');\nasync function Call() { ${args.join(' ')} }; Call();`;
		let result = eval(query);
		message.channel.send(lang.buildEmbed(message, [
			{
				"from": "query",
				"to": args.join(' ')
			},
			{
				"from": "inspected",
				"to": inspect(result, { depth: 0 })
			},
			{
				"from": "type",
				"to": typeof result
			},
			{
				"from": "time",
				"to": process.hrtime(time).toString().replace(',', '.')
			}
		])[0])
	} catch(err) {
		message.channel.send(lang.buildEmbed(message, [
			{
				"from": "query",
				"to": args.join(' ')
			},
			{
				"from": "error",
				"to": err
			}
		])[1])
	}
}

module.exports.config = {
	name: 'eval',
	permissionLevel: 5,
	aliases: [],
	filename: 'dev/eval.js',
	disabled: false,
	description: {
		pl: "Wywołuje podany kod JavaScript",
		en: "Evaluates given JavaScript code"
	},
	ussuage: {
		pl: "{prefix}eval <Kod JavaScript>",
		en: "{prefix}eval <JavaScript code>"
	}
}
