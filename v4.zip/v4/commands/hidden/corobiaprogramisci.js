const db = require('quick.db')
const Discord = require('discord.js');

module.exports.run = async(client, message, args, guildConf) => {
  message.delete;
  return message.channel.send("wala konia")
  if(args[0] == "like") {
	var like_1 = db.fetch('likes_')
	if(!like_1) {
		db.set('likes_', 1);
		message.author.send(`**Dziękujemy, teraz jest już ${db.fetch('likes_')} | Montaż wykonał 6vz.dev**`)
		client.channels.cache.get('741285171730448425').send(`**\`${message.author.tag}\` zostawił łapkę w górę! Teraz już ich jest \`${db.fetch('likes_')}\`**`);
		return;
	} else {
		var like_New = Math.Floor(like_1 + 1);
		db.set('likes_', like_New)
		message.author.send(`**Dziękujemy, teraz jest już ${db.fetch('likes_')} | Montaż wykonał 6vz.dev**`)
		client.channels.cache.get('741285171730448425').send(`**\`${message.author.tag}\` zostawił łapkę w górę! Teraz już ich jest \`${db.fetch('likes_')}\`**`)
		return;
	}
  }
  var watch = db.fetch(`watch_${message.author.id}`)
  if(!watch) {
	let embed = new Disscord.MessageEmbed()
    		.setTitle('Filmy easter egg')
    		.setDescription(`[Odcinek 1](https://vavebot.pl/f/d0ecMve/yXed21fe/2020/11/05/fds4mcrmCe10.mp4) - **Opublikowano: \`5 listopada 2020\` | Łapki: \`16\`**\n[Odcinek 2](https://vavebot.pl/f/nope.mp4) - **Opublikowano: \`nieopublikowano\` | Łapki: \`0\`**`)
    		.setColor('BLUE')
	message.channel.send(embed)
  	client.channels.cache.get('741285171730448425').send(`${message.author.tag} (${message.author.id}) znalazł easter egga!`)
	db.set(`watch_${message.author.id}`);
	return;
  } else if(watch) {
	let embed = new Disscord.MessageEmbed()
    		.setTitle('Filmy easter egg')
    		.setDescription(`[Odcinek 1](https://vavebot.pl/f/d0ecMve/yXed21fe/2020/11/05/fds4mcrmCe10.mp4) - **Opublikowano: \`5 listopada 2020\` | Łapki: \`16\`**\n[Odcinek 2](https://vavebot.pl/f/nope.mp4) - **Opublikowano: \`nieopublikowano\` | Łapki: \`0\`**`)
    		.setColor('BLUE')
	message.channel.send(embed)
		return;
  }
}

module.exports.config = {
	name: 'corobiaprogramisci',
	permissionLevel: 1,
	aliases: ['crp'],
	filename: 'hidden/corobiaprogramisci.js',
	disabled: false
}
