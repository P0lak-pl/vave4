# vave Bot v4

# Run

To start bot for command developing use `npm run dev`<br>
To start bot for library developing use `npm run devrl`<br>
To start bot for production use `npm run production` (Starts new PM2 process)
