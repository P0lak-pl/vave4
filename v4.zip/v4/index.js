const Discord = require('discord.js');
const fs = require('fs');
const db = require('quick.db');
const chalk = require('chalk');
const Enmap = require('enmap');
const logSymbols = require('log-symbols');
const config = require('./config.json');
const lib = require('./lib/index.js');
const moment = require('moment');

const client = new Discord.Client();

client.commands = new Discord.Collection();
const cooldowns = new Discord.Collection();
client.queue = new Map();

client.settings = new Enmap({
	name: 'settings',
	fetchAll: false,
	autoFetch: true,
	cloneLevel: 'deep'
});

lib.ClientFunction(client);
console.log(client.functions);

fs.readdirSync(__dirname + "/commands/").forEach(dir => {
	const commands = fs.readdirSync(__dirname + `/commands/${dir}/`).filter(f => f.endsWith(".js"));

	commands.forEach((file, i) => {
		let cmd = require(__dirname + `/commands/${dir}/${file}`);

		/*client.commands.set(cmd.config.name, {
			"run": cmd.run,
			"name": cmd.config.name,
			"permissions": cmd.config.permissionLevel,
			"aliases": cmd.config.aliases,
			"filename": dir + '/' + file,
			"disabled": cmd.config.disabled
		});*/

		client.commands.set(cmd.config.name, cmd)
	
		console.log(logSymbols.info, `[${client.commands.size}] ${chalk.cyan(dir + '/' + file)} loaded!`);
	});
});

client.on('ready', () => {
	console.log(logSymbols.success, `Logged in as ${chalk.cyan(client.user.tag)}, serving for ${chalk.cyan(client.guilds.cache.size)} guilds & ${chalk.cyan(client.users.cache.size)} users!`);
	//console.log(client.commands.forEach(x => console.log(x)));
	const activities_list = ['v4 is coming soon... | %help', 'vavebot.pl | %help', `vavebot.pl | ${client.guilds.cache.size} guilds`, 'vavebot.pl | %config'];
        setInterval(() => {
        	const index = Math.floor(Math.random() * (activities_list.length - 1) + 1);
        	client.user.setActivity(activities_list[index]);
    	}, 30000);
});

client.on('message', async(message) => {
	const guildConf = client.settings.ensure(message.guild.id, config.defaultGuildSettings);
	const lang = 'pl';

	if(message.author.bot) return;

	client.functions.xp(message, guildConf);

	if(client.functions.getUserFromMention(message.content, client) && client.functions.getUserFromMention(message.content, client).id == client.user.id) {
		message.channel.send('Ping');
		return;
	}
	
	if(!message.content.indexOf(guildConf.prefix) == 0) return;
	
	const messageArray = message.content.split(/\s+/g);
	const command = messageArray[0].toLowerCase();
	const args = messageArray.slice(1);


	const cmd = client.commands.get(command.slice(guildConf.prefix.length)) || client.commands.find(cmd => cmd.config.aliases && cmd.config.aliases.includes(command.slice(guildConf.prefix.length)));

	if(!cmd) return message.react('❌');

	if (!cooldowns.has(cmd.config.name)) {
		cooldowns.set(cmd.config.name, new Discord.Collection());
	}

	const now = Date.now();
	const timestamps = cooldowns.get(cmd.config.name);
	const cooldownAmount = (cmd.config.cooldown || 3) * 1000;

	if (timestamps.has(message.author.id)) {
		const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

		if (now < expirationTime) {
			const timeLeft = (expirationTime - now) / 1000;
			message.channel.send(new client.LanguageHandler('_/_cooldown', 'pl').buildEmbed(message, [
				{
					"from": "time",
					"to": timeLeft.toFixed(1)
				},
				{
					"from": "name",
					"to": cmd.config.name
				}
			]));
			return;
		}
	}

	timestamps.set(message.author.id, now);
	setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
	
	if(cmd.config.disabled) {
		if(client.functions.getUserPermissionLevel(message.author.id) == '5') {
			message.channel.send('<:windows_i:759388355141697536> **Komenda jest wyłączona, lecz posiadasz permisje do aktywawania jej!**');
			try {
				await cmd.run(client, message, args, guildConf);
			} catch(err) {
				message.channel.send(new client.LanguageHandler('_/_err_error', 'pl').buildEmbed(message));
				client.channels.cache.get('').send('', embed)
			}
		} else {
			message.channel.send(new client.LanguageHandler('_/_err_cmdDisabled', 'pl').buildEmbed(message));
		}
	} else if(client.functions.getUserPermissionLevel(message.author.id) == '0') {
		message.channel.send(new client.LanguageHandler('_/_err_ban', 'pl').buildEmbed(message, [
			{
				"from": "reason",
				"to": db.get(`GlobalBan_${message.author.id}_reason`)
			},
			{
				"from": "date",
				"to": moment(db.get(`GlobalBan_${message.author.id}_date`)).format('DD.MM.YYYY HH:mm:ss')
			}
		]));
	} else if(cmd.config.permissionLevel > parseInt(client.functions.getUserPermissionLevel(message.author.id))) {
		message.channel.send(new client.LanguageHandler('_/_err_perms', 'pl').buildEmbed(message, [
			{
				"from": "perms",
				"to": new client.LanguageHandler('_/_err_perms', 'pl').permissionLevels(cmd.config.permissionLevel)
			}
		]));
	} else {
		try {
			if(cmd.config.args !== 0 && !args.length >= cmd.config.args) {
				return message.channel.send(new client.LanguageHandler('_/_err_args', 'pl').buildEmbed(message, [
					{
						"from": "ussuage",
						"to": cmd.config.ussuage.pl.replace('{prefix}', guildConf.prefix)
					}
				]))
			}
			await cmd.run(client, message, args, guildConf);
		} catch(err) {
			console.log('Error')
			message.channel.send(new client.LanguageHandler('_/_err_error', 'pl').buildEmbed(message));
			const embed = new Discord.MessageEmbed()
				.setTitle('Error')
				.setDescription(`Command: \`${cmd.config.name}\`\nFile: \`${cmd.config.filename}\`\n\`\`\`yaml\n${err.stack}\`\`\``)
				.setFooter(client.footer)
				.setTimestamp()
				.setColor('RED')
			client.channels.cache.get('775003637214085120').send(embed);
		}
	}
});

client.login(config.token);
